# GenAlg

This is my genetic algorithm!
It's still in it's early stages. 

Documentation can be found [here](https://awon8465.github.io/GenAlgDoc/index.html) (Still in progress)

## Demo: Himmelblau's function

<p align = "center">
  <img src="Himmelblau_function.png" width="40%">
</p>

Source:[wikipedia](https://en.wikipedia.org/wiki/Himmelblau%27s_function) 

Here is a demonstration of my genetic algorithm exploring the four minima of Himmelblau's function simultaneously.

<p align = "center">
  <img src="demo-himmelblau/x_y_progression.gif">
</p>
