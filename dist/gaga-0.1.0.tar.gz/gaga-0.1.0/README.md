# GAGA

This is my genetic algorithm!
It's still in it's early stages. 

Hopefully you can pip install it.

Documentation can be found [here](https://awon8465.github.io/gagadoc/index.html) (Still in progress)

## Demo: Himmelblau's function
(*See Demo Himmelblau.ipynb*) 

<p align = "center">
  <img src="demos/Himmelblau_function.png" width="40%">
</p>

Source:[wikipedia](https://en.wikipedia.org/wiki/Himmelblau%27s_function) 

Here is a demonstration of my genetic algorithm exploring the four minima of Himmelblau's function simultaneously.

<p align = "center">
  <img src="demo/demo-himmelblau/x_y_progression.gif">
</p>
