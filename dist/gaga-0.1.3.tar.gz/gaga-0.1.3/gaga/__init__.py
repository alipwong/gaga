from gaga.GA import ga
from gaga.Results import Results

def main():
    pass

if __name__ == "__main__":
    main()