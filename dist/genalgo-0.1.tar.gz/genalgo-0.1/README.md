# genetic-algorithm

## Demo: Himmelblau's function

<p align = "center">
  <img src="demo/Himmelblau_function.png" width="40%">
</p>

Source:[wikipedia](https://en.wikipedia.org/wiki/Himmelblau%27s_function) 

Here is a demonstration of my genetic algorithm exploring the four minima of Himmelblau's function simultaneously.

<p align = "center">
  <img src="demo/1_x_y_0.1_0_progression.gif">
</p>
