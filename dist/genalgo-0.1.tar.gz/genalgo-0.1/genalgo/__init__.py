from genalgo.GA import GA
from genalgo.Results import Results